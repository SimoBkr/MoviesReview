package dev.simobkr.moviesbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
